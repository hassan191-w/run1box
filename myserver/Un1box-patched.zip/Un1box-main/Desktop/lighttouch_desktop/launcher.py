"""Shared Tk library/setup/session UI. Native behavior is supplied by a host adapter.

This module imports no Linux process/storage/service implementation. Desktop
platforms use this same class and layout; adapters never copy its widgets.
"""
import queue
import re
import shutil
from pathlib import Path
import time
import uuid

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .profiles import InterruptedStateError
from .prepared_import import packed_folder

PALETTE = {"paper": "#F3F6FA", "ink": "#1C304A", "muted": "#596C83", "blue": "#285BB5", "line": "#D9E2EF", "white": "#FFFFFF"}


class ScrollPanel(ttk.Frame):
    """Keep setup fields reachable while the session controls stay on screen."""
    def __init__(self, parent):
        super().__init__(parent)
        self.canvas = tk.Canvas(self, background=PALETTE["paper"], highlightthickness=0, width=1, height=1)
        bar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.content = ttk.Frame(self.canvas, padding=16)
        item = self.canvas.create_window(0, 0, window=self.content, anchor="nw")
        self.content.bind("<Configure>", lambda _: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda event: self.canvas.itemconfigure(item, width=event.width))
        top = self.winfo_toplevel()
        for event in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            top.bind(event, self.wheel, add="+")
        top.bind("<FocusIn>", self.reveal_focus, add="+")

    def contains(self, widget):
        while widget is not None:
            if widget is self:
                return True
            widget = getattr(widget, "master", None)
        return False

    def wheel(self, event):
        if self.contains(event.widget):
            step = -1 if getattr(event, "num", None) == 4 or getattr(event, "delta", 0) > 0 else 1
            self.canvas.yview_scroll(step * 3, "units")
            return "break"

    def reveal_focus(self, event):
        if not self.contains(event.widget) or event.widget in (self.canvas, self):
            return
        y = event.widget.winfo_rooty() - self.content.winfo_rooty()
        height = max(1, self.content.winfo_height())
        first, last = self.canvas.yview()
        if y < first * height:
            self.canvas.yview_moveto(y / height)
        elif y + event.widget.winfo_height() > last * height:
            self.canvas.yview_moveto((y + event.widget.winfo_height() - self.canvas.winfo_height()) / height)


class Launcher:
    def __init__(self, window, args, host):
        self.window, self.args, self.host = window, args, host
        self.store = host.open_profiles(args.data_dir)
        self.session = host.create_session(self.store.directory / "logs" / ("application-" + uuid.uuid4().hex + ".log"))
        self.bridge = None
        self.apps = None
        self.current = None
        self.closing = False
        self.job = ""
        self.pending_import = None
        self.preparation = None
        self.selected_source = None
        self.setup_started = None
        self.cancel_requested = False
        self.last_metrics = 0
        self.system_file = tk.StringVar()
        self.install_parent = tk.StringVar(value=str(self.store.directory / "bases"))
        self.device_summary = tk.StringVar()
        self.selection_hint = tk.StringVar(value="Extract your guest ZIP, then choose the three files below in order.")
        self.was_active = False
        self.widgets = []
        self.vars = {name: tk.StringVar() for name in ("name", "base", "state", "guest_package", "bootrom")}
        self.audio = tk.BooleanVar(value=True)
        self.recovery_profile = None
        self.recheck = tk.BooleanVar(value=False)
        self.message = tk.StringVar(value="Choose a device, or add a prepared base to get started.")
        self.detail = tk.StringVar(value="Choose an installed system or import a prepared .itbase file.")
        self.stats = tk.StringVar(value="Worker CPU and memory become available after Start.")
        self._build()
        for variable in (*self.vars.values(), self.audio):
            variable.trace_add("write", lambda *_: self.clear_recovery())
        self._list()
        if not self.current:
            self.new()
        self.window.protocol("WM_DELETE_WINDOW", self.close)
        self.window.after(200, self.tick)

    def _build(self):
        self.window.title("LightTouch")
        # Leave room for desktop panels and window decorations on 768px displays.
        available_width = max(320, self.window.winfo_screenwidth() - 64)
        available_height = max(240, self.window.winfo_screenheight() - 96)
        self.window.geometry(f"{min(1040, available_width)}x{min(810, available_height)}")
        self.window.minsize(min(950, available_width), min(540, available_height))
        self.window.configure(bg=PALETTE["paper"])
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(".", font=(self.host.font_family, 10), background=PALETTE["paper"], foreground=PALETTE["ink"])
        style.configure("TButton", padding=(12, 8))
        style.configure("TEntry", padding=7, fieldbackground=PALETTE["white"])
        style.configure("Title.TLabel", font=(self.host.font_family, 23, "bold"))
        style.configure("Heading.TLabel", font=(self.host.font_family, 15, "bold"))
        style.configure("Muted.TLabel", foreground=PALETTE["muted"])
        style.configure("Accent.TButton", background=PALETTE["blue"], foreground="white")
        style.map("Accent.TButton", background=[("active", "#204B96"), ("disabled", "#A4B7D4")])
        shell = ttk.Frame(self.window, padding=24)
        shell.pack(fill="both", expand=True)
        top = ttk.Frame(shell)
        top.pack(fill="x", pady=(0, 22))
        ttk.Label(top, text="LightTouch", style="Title.TLabel").pack(side="left")
        ttk.Label(top, text="Run a classic iOS device", style="Muted.TLabel").pack(side="left", padx=18, pady=(8, 0))
        body = ttk.Frame(shell)
        body.pack(fill="both", expand=True)
        sidebar = ttk.Frame(body, width=190, padding=(0, 0, 22, 0))
        sidebar.pack(side="left", fill="y")
        ttk.Label(sidebar, text="Saved devices", style="Heading.TLabel").pack(anchor="w", pady=(0, 12))
        self.devices = tk.Listbox(sidebar, bg=PALETTE["white"], fg=PALETTE["ink"], selectbackground=PALETTE["blue"],
                                  selectforeground="white", relief="flat", highlightthickness=1,
                                  highlightbackground=PALETTE["line"], font=(self.host.font_family, 10), width=21,
                                  exportselection=False, activestyle="none")
        self.devices.pack(fill="both", expand=True)
        self.devices.bind("<<ListboxSelect>>", self.select)
        horizontal = ttk.Scrollbar(sidebar, orient="horizontal", command=self.devices.xview)
        self.devices.configure(xscrollcommand=horizontal.set)
        horizontal.pack(fill="x")
        ttk.Label(sidebar, textvariable=self.device_summary, wraplength=185,
                  justify="left", style="Muted.TLabel").pack(fill="x", pady=(8, 0))
        self.widgets.append(self.devices)
        self.button(sidebar, "+ Add iOS device", self.new).pack(fill="x", pady=(12, 0))
        self.button(sidebar, "New from selected", self.new_instance).pack(fill="x", pady=(8, 0))
        content = ttk.Frame(body)
        content.pack(side="left", fill="both", expand=True)
        # Pack the footer first so it retains space when the window is short.
        footer = ttk.Frame(content)
        footer.pack(side="bottom", fill="x", pady=(12, 0))
        self.heading = ttk.Label(content, text="Add iOS device", style="Heading.TLabel")
        self.heading.pack(anchor="w", pady=(0, 12))
        notebook = ttk.Notebook(content)
        notebook.pack(fill="both", expand=True)
        setup_panel = ScrollPanel(notebook)
        advanced_panel = ScrollPanel(notebook)
        setup, advanced = setup_panel.content, advanced_panel.content
        diagnostics = ttk.Frame(notebook, padding=16)
        notebook.add(setup_panel, text="  iOS files  ")
        notebook.add(advanced_panel, text="  Advanced  ")
        notebook.add(diagnostics, text="  Session details  ")
        ttk.Label(setup, textvariable=self.selection_hint, wraplength=620, style="Muted.TLabel").pack(anchor="w", pady=(0, 12))
        for title, hint, variable, action, caption in (
            ("1   iOS system", "Choose n72ap-7E18.itbase for iOS 3.1.3, or a prepared folder from Light Touch for Mac for other devices (iPod touch 4G).", self.system_file, self.choose_system, "Choose .itbase…"),
            ("2   Guest tools", "Choose armv6.itpack for iOS 3.1.3 (armv7.itpack for iPod touch 4).", self.vars["guest_package"], lambda: self.browse("guest_package", "file"), "Choose .itpack…"),
            ("3   Boot file", "Choose bootrom.bin for iOS 3.1.3. iPod touch 4 does not need this file.", self.vars["bootrom"], lambda: self.browse("bootrom", "file"), "Choose boot file…"),
        ):
            row = ttk.Frame(setup)
            row.pack(fill="x", pady=(0, 16))
            ttk.Label(row, text=title, font=(self.host.font_family, 11, "bold")).pack(anchor="w")
            ttk.Label(row, text=hint, style="Muted.TLabel", wraplength=620).pack(anchor="w", pady=(3, 6))
            picker = ttk.Frame(row)
            picker.pack(fill="x")
            if variable is self.vars["bootrom"]:
                self.button(picker, "Clear", lambda: self.vars["bootrom"].set("")).pack(side="right", padx=(8, 0))
            if variable is self.system_file:
                self.button(picker, "Choose folder…", self.choose_system_folder).pack(side="right", padx=(8, 0))
            self.button(picker, caption, action).pack(side="right", padx=(8, 0))
            entry = ttk.Entry(picker, textvariable=variable, state="readonly")
            entry.pack(side="left", fill="x", expand=True)
            variable.trace_add("write", lambda *_, entry=entry: self.window.after_idle(entry.xview_moveto, 1))
        ttk.Label(setup, text="Your original files stay unchanged. Setup checks and unpacks the system once;\nyour iOS changes are saved separately. Checks run automatically.",
                  style="Muted.TLabel", justify="left", wraplength=620).pack(anchor="w", pady=(0, 10))
        form = ttk.Frame(advanced)
        form.pack(fill="x")
        form.columnconfigure(1, weight=1)
        self.field(form, 0, "Device name", "name")
        self.field(form, 1, "Installed system folder", "base", "folder")
        self.field(form, 2, "Saved iOS changes", "state", "folder")
        ttk.Label(form, text="Install new systems in").grid(row=3, column=0, sticky="w", padx=(0, 12), pady=5)
        location = ttk.Entry(form, textvariable=self.install_parent)
        location.grid(row=3, column=1, sticky="ew", pady=5)
        self.widgets.append(location)
        self.button(form, "Choose folder…", self.choose_storage).grid(row=3, column=2, padx=(8, 0), pady=5)
        ttk.Label(advanced, text="Already imported your system? Select its folder above (the folder containing device.lock.json). It will be used without copying.\n\nStorage is managed automatically. Change these paths only to reuse or relocate an existing device.",
                  style="Muted.TLabel", wraplength=600).pack(anchor="w", pady=12)
        if getattr(self.host, "supports_validation_cache", False):
            recheck = ttk.Checkbutton(advanced, text="Recheck all system files before starting (slow)", variable=self.recheck)
            recheck.pack(anchor="w", pady=8)
            self.widgets.append(recheck)
        config = ttk.Frame(advanced)
        config.pack(fill="x", pady=12)
        self.button(config, "Import settings…", self.import_profile).pack(side="left")
        self.button(config, "Export settings…", self.export_profile).pack(side="left", padx=8)
        self.button(advanced, "Save device settings", self.save).pack(anchor="w")
        ttk.Label(diagnostics, textvariable=self.stats, justify="left", wraplength=610).pack(anchor="w", pady=(0, 12))
        ttk.Button(diagnostics, text="Copy diagnostic log", command=self.copy_diagnostics).pack(anchor="w", pady=(0, 10))
        self.log = tk.Text(diagnostics, height=8, bg=PALETTE["white"], fg=PALETTE["ink"], relief="flat",
                           font=("DejaVu Sans Mono", 9), wrap="word", state="disabled")
        self.log.pack(fill="both", expand=True)
        ttk.Label(footer, textvariable=self.message, font=(self.host.font_family, 11, "bold"), wraplength=650).pack(anchor="w", pady=(0, 4))
        ttk.Label(footer, textvariable=self.detail, style="Muted.TLabel", wraplength=650).pack(anchor="w", pady=(0, 8))
        self.progress = ttk.Progressbar(footer, mode="determinate", maximum=100)
        self.progress.pack(fill="x", pady=(0, 10))
        actions = self.actions = ttk.Frame(footer)
        actions.pack(fill="x")
        self.recovery_button = self.button(footer, "Boot recovered state", self.boot_recovered_state, "Accent.TButton")
        self.start_button = self.button(actions, "Start iOS", self.start, "Accent.TButton")
        self.start_button.pack(side="left")
        self.stop_button = ttk.Button(actions, text="Stop iOS", command=self.stop, state="disabled")
        self.stop_button.pack(side="left", padx=8)
        self.cancel_button = ttk.Button(actions, text="Cancel setup", command=self.cancel_setup, state="disabled")
        self.cancel_button.pack(side="left")
        self.apps_button = ttk.Button(actions, text="Install apps…", command=self.open_apps, state="disabled")
        self.apps_button.pack(side="right")
        audio = ttk.Checkbutton(actions, text="Sound", variable=self.audio)
        audio.pack(side="right", padx=8)
        self.widgets.append(audio)

    def set_busy(self, busy):
        for widget in self.widgets:
            widget.configure(state="disabled" if busy else "normal")
        self.cancel_button.configure(state="normal" if busy and self.job != "guest" else "disabled")

    def choose_system(self):
        source = filedialog.askopenfilename(parent=self.window, title="Step 1: choose n72ap-7E18.itbase (iOS 3.1.3)",
                                           filetypes=[("iOS system (.itbase)", "*.itbase"), ("All files", "*")])
        if source:
            self.use_system(source)

    def choose_system_folder(self):
        source = filedialog.askdirectory(parent=self.window, title="Step 1: choose the prepared folder (it holds index.json)", mustexist=True)
        if not source:
            return
        if not packed_folder(source):
            self.error(ValueError("This folder is not a prepared iOS system. Choose the .itbase folder Light Touch for Mac made (it holds index.json and files)."))
            return
        self.use_system(source)

    def use_system(self, source):
        if not self.current or any(p["id"] == self.current and p.get("base") for p in self.store.devices):
            self.new()
        self.selected_source = source
        self.system_file.set(source)
        self.vars["base"].set("")
        parent = Path(source).parent
        self.vars["guest_package"].set("")
        self.vars["bootrom"].set("")
        packages = list(parent.glob("*.itpack"))
        armv7 = "n81" in Path(source).name.lower() or packed_folder(source)
        preferred = parent / ("armv7.itpack" if armv7 else "armv6.itpack")
        if preferred.is_file():
            self.vars["guest_package"].set(str(preferred))
        elif len(packages) == 1:
            self.vars["guest_package"].set(str(packages[0]))
        if not armv7 and (parent / "bootrom.bin").is_file():
            self.vars["bootrom"].set(str(parent / "bootrom.bin"))
        self.start_button.configure(text="Set up device")
        self.message.set("iOS system selected. Check the guest tools and boot file, then Set up device.")
        self.detail.set("Setup will calculate checksums automatically and keep your original files unchanged.")

    def choose_storage(self):
        value = filedialog.askdirectory(parent=self.window, title="Choose storage for new iOS systems", mustexist=False)
        if value:
            self.install_parent.set(value)

    def button(self, parent, title, action, style="TButton"):
        widget = ttk.Button(parent, text=title, command=action, style=style)
        self.widgets.append(widget)
        return widget

    def field(self, parent, row, label, name, browse=None):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 12), pady=5)
        entry = ttk.Entry(parent, textvariable=self.vars[name], state="readonly" if name == "base" else "normal")
        entry.grid(row=row, column=1, sticky="ew", pady=5)
        if name != "base":
            self.widgets.append(entry)
        if browse:
            title = "Choose folder…" if browse == "folder" else "Choose file…"
            self.button(parent, title, lambda: self.browse(name, browse)).grid(row=row, column=2, padx=(8, 0), pady=5)

    def browse(self, name, kind):
        titles = {"base": "Choose the imported folder containing device.lock.json", "state": "Choose where to save iOS changes",
                  "guest_package": "Step 2: choose armv6.itpack (iOS 3.1.3)", "bootrom": "Step 3: choose bootrom.bin (iOS 3.1.3)"}
        types = [("Guest tools (.itpack)", "*.itpack"), ("All files", "*")] if name == "guest_package" else [("Boot file (.bin)", "*.bin"), ("All files", "*")]
        value = filedialog.askdirectory(parent=self.window, title=titles[name], mustexist=name != "state") if kind == "folder" else filedialog.askopenfilename(parent=self.window, title=titles[name], filetypes=types)
        if value:
            if name == "base" and any(p["id"] == self.current and p.get("base") != value for p in self.store.devices):
                self.new()
            self.vars[name].set(value)
            if name == "base":
                self.selected_source = None
                self.system_file.set(value)
                self.start_button.configure(text="Start iOS")
                self.message.set("Installed system selected. No import or extra copy is needed.")
                try:
                    if self.host.inspect_base(value)["board"] == "n81ap":
                        self.vars["bootrom"].set("")
                except (ValueError, OSError, RuntimeError):
                    pass  # The regular Start validation supplies the actionable error.

    def _list(self):
        self.devices.delete(0, "end")
        for index, device in enumerate(self.store.devices):
            try:
                info = self.host.inspect_base(device["base"])
                title = self.host.display_title(device["name"], info["board"], info["build"])
            except (ValueError, OSError, RuntimeError, KeyError):
                title = device["name"] + " · assets unavailable"
            self.devices.insert("end", title)
            if device["id"] == self.store.selected:
                self.devices.selection_set(index)
                self._load(device)

    def _load(self, device):
        self.current = device["id"]
        self.selected_source = None
        self.system_file.set(device.get("base", ""))
        self.start_button.configure(text="Start iOS" if device.get("base") else "Choose iOS system…")
        for name, value in self.vars.items():
            value.set(device.get(name, ""))
        self.audio.set(device.get("audio", True))
        self.clear_recovery()
        self.heading.configure(text=device["name"] if device.get("base") else "Add iOS device")
        if device.get("base"):
            try:
                info = self.host.inspect_base(device["base"])
                title = self.host.display_title(device["name"], info["board"], info["build"])
            except (ValueError, OSError, RuntimeError, KeyError):
                title = device["name"] + " · assets unavailable"
            self.device_summary.set(title.replace(" · ", "\n"))
            self.selection_hint.set("Saved configuration. Start reuses these iOS files and this device's own saved state.")
        else:
            self.device_summary.set("New configuration\nIts saved state will be separate.")
            self.selection_hint.set("Extract your guest ZIP, then choose the files below in order.")

    def select(self, _event=None):
        if self.session.active or self.preparation or not self.devices.curselection():
            return
        device = self.store.devices[self.devices.curselection()[0]]
        self._load(device)
        self.store.selected = device["id"]
        self.store.persist()
        self.message.set("Ready to check prepared assets.")

    def new(self):
        identity = uuid.uuid4().hex
        self._load({"id": identity, "name": "iPod touch", "state": self.store.new_state(identity), "audio": True})
        self.devices.selection_clear(0, "end")
        self.message.set("Choose the iOS system file in step 1.")
        self.detail.set("For iOS 3.1.3: n72ap-7E18.itbase, armv6.itpack, bootrom.bin.")

    def new_instance(self):
        if self.session.active or self.preparation:
            return
        try:
            self.store.new_instance(self.current)
            self._list()
            self.message.set("New device saved. Ready to start iOS.")
            self.detail.set("Uses the same iOS system with fresh saved data. Your original device stays unchanged.")
        except (ValueError, OSError, RuntimeError) as error:
            self.error(error)

    def profile(self):
        if not self.current:
            self.current = uuid.uuid4().hex
        result = {"id": self.current, "audio": self.audio.get()}
        result.update({name: value.get().strip() for name, value in self.vars.items()})
        if not result["state"]:
            result["state"] = self.store.new_state(self.current)
            self.vars["state"].set(result["state"])
        return result

    def error(self, error):
        self.session.record_error("launcher", error)
        self.message.set(str(error))
        messagebox.showerror("LightTouch", str(error), parent=self.window)

    def save(self):
        try:
            profile = self.profile()
            info = self.host.validate(profile, allow_dirty=True)
            self.store.save(profile)
            self._list()
            self.message.set("Saved · " + info["board"] + " · " + info["build"])
        except (ValueError, OSError, RuntimeError) as error:
            self.error(error)

    def import_profile(self):
        name = filedialog.askopenfilename(parent=self.window, title="Import LightTouch configuration", filetypes=[("LightTouch configuration", "*.json"), ("All files", "*")])
        if not name:
            return
        try:
            profile = self.host.load_profile(name)
            self.store.save(profile)
            self._list()
            self.message.set("Configuration imported. Assets will be verified before boot.")
        except (ValueError, OSError, RuntimeError) as error:
            self.error(error)

    def export_profile(self):
        try:
            profile = self.profile()
            self.host.validate(profile, allow_dirty=True)
            name = filedialog.asksaveasfilename(parent=self.window, title="Export configuration", defaultextension=".json")
            if name:
                self.host.export_profile(name, profile)
        except (ValueError, OSError, RuntimeError) as error:
            self.error(error)

    def import_base(self):
        if not self.vars["guest_package"].get():
            self.error(ValueError("Step 2: choose armv6.itpack for iOS 3.1.3, or armv7.itpack for iPod touch 4."))
            return
        if "n72" in Path(self.selected_source).name.lower() and not self.vars["bootrom"].get():
            self.error(ValueError("Step 3: choose bootrom.bin for this iOS 3.1.3 system."))
            return
        try:
            parent = Path(self.install_parent.get()).expanduser().absolute()
            self.store.storage.ensure_directory(parent)
            self.pending_import = str(parent / ("system-" + uuid.uuid4().hex))
        except OSError as error:
            self.error(error)
            return
        self.preparation = self.host.prepare(self.selected_source)
        self.setup_started = time.monotonic()
        self.cancel_requested = False
        self.import_bytes = None
        self.job = "prepare"
        self.set_busy(True)
        self.progress["value"] = 0
        self.message.set("Checking the iOS system file…")
        self.detail.set("Calculating its checksum automatically. Your files stay unchanged.")
        self.preparation.start()

    def cancel_setup(self):
        self.cancel_requested = True
        self.cancel_button.configure(state="disabled")
        self.message.set("Cancelling setup…")
        if self.preparation:
            self.preparation.cancelled.set()
        elif self.session.active and self.job == "import":
            try:
                self.session.stop()
            except (OSError, RuntimeError) as error:
                self.error(error)

    def launch(self, command, job, env=None):
        log = self.store.directory / "logs" / (time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:8] + ".log")
        self.session.start(command, log, env=env)
        self.job = job
        self.was_active = True
        self.set_busy(True)
        self.stop_button.configure(state="normal" if job == "guest" else "disabled")
        self.progress["value"] = 0
        self.import_bytes = None
        self.message.set("Starting iOS…" if job == "guest" else "Preparing the iOS system…")
        self.detail.set("The first setup expands the system and checks its contents. This can take several minutes." if job == "import" else "Your iOS display will open in a separate window.")

    def clear_recovery(self):
        self.recovery_profile = None
        self.recovery_button.pack_forget()

    def boot_recovered_state(self):
        # A recovery decision belongs only to the device/configuration shown.
        if self.recovery_profile is not None and self.profile() == self.recovery_profile:
            self.start(recover=True)

    def guest_command(self, profile, recover):
        if getattr(self.host, "supports_validation_cache", False):
            return self.host.guest_command(self.args, profile, recover, recheck=self.recheck.get())
        return self.host.guest_command(self.args, profile, recover)

    def start(self, recover=False):
        if self.session.active or self.preparation:
            return
        self.clear_recovery()
        if self.selected_source:
            self.import_base()
            return
        if not self.vars["base"].get():
            self.choose_system()
            return
        try:
            if self.apps and self.apps.window.winfo_exists():
                if self.apps.busy:
                    raise ValueError("Wait for the Apps operation before starting a fresh guest.")
                self.apps.window.destroy()
                self.apps = None
            profile = self.profile()
            command = self.guest_command(profile, recover)
            self.store.save(profile)
            self.bridge, env = self.host.start_services(self.args, self.store.directory, self.current)
            self.launch(command, "guest", env=env)
            self.apps_button.configure(text="Install apps…" if self.bridge else "Install apps (unavailable)")
            if self.bridge is None:
                self.detail.set("Install apps is unavailable: guest app services are not connected in this platform preview. Log: " + str(self.session.log_path))
        except InterruptedStateError as error:
            # Validate the entire command, including runtime files checked after
            # dirty-state admission. This only prepares arguments; it never boots.
            try:
                self.guest_command(profile, True)
            except (ValueError, OSError, RuntimeError) as validation_error:
                self.error(validation_error)
                return
            self.session.record_error("launcher", error)
            self.recovery_profile = dict(profile)
            self.recovery_button.pack(anchor="w", before=self.actions, pady=(0, 8))
            self.message.set("The previous session ended unexpectedly. Your saved iOS data was retained.")
            self.detail.set("Choose Boot recovered state to cold boot this device using its saved data. Recovery applies to this start only.")
            self.recovery_button.focus_set()
        except (ValueError, OSError, RuntimeError) as error:
            if self.bridge:
                self.bridge.close()
                self.bridge = None
            self.error(error)

    def open_apps(self):
        if self.apps and self.apps.window.winfo_exists():
            self.apps.window.lift()
            return
        if not self.session.active or self.job != "guest" or self.session.stopping or not self.bridge:
            self.error(ValueError("Start iOS with the bundled guest app services to use Apps."))
            return
        self.apps = self.host.apps_window(self.window, lambda: self.bridge, self.store.directory / "app-downloads",
                               lambda: self.session.active and self.job == "guest" and not self.session.stopping,
                               on_error=lambda error: self.session.record_error("apps", error))

    def copy_diagnostics(self):
        try:
            report = self.session.diagnostic_report()
            self.window.clipboard_clear()
            self.window.clipboard_append(report)
            self.message.set("Diagnostic log copied. It includes app errors, graphics startup and recent guest output.")
            self.detail.set("Logs: " + str(self.store.directory / "logs"))
        except (OSError, RuntimeError) as error:
            self.error(error)

    def stop(self):
        try:
            if self.apps and self.apps.window.winfo_exists():
                self.apps.before_stop()
            self.session.stop()
            self.stop_button.configure(state="disabled")
            self.message.set("Stopping guest… state is retained until shutdown is confirmed.")
        except (ValueError, OSError, RuntimeError) as error:
            self.closing = False
            self.error(error)

    def close(self):
        if self.preparation or (self.session.active and self.job == "import"):
            self.closing = True
            self.cancel_setup()
            return
        if self.session.active:
            if messagebox.askyesno("Stop guest and close?", "LightTouch will request a safe shutdown and wait for its result. Your writable state will be retained.", parent=self.window):
                self.closing = True
                self.stop()
        else:
            if self.apps and self.apps.busy:
                self.error(ValueError("Wait for the Apps operation to finish before closing."))
                return
            self.window.destroy()

    def tick(self):
        if self.preparation:
            prep = self.preparation
            while True:
                try:
                    done, total = prep.events.get_nowait()
                    percent = 100 * done / max(1, total)
                    self.progress["value"] = percent
                    self.detail.set("Checking file: %.0f%% · %.0f MiB of %.0f MiB · %ds elapsed" % (percent, done / 1024**2, total / 1024**2, time.monotonic() - self.setup_started))
                except queue.Empty:
                    break
            if not prep.active:
                self.preparation = None
                if prep.error or self.cancel_requested:
                    self.set_busy(False)
                    self.cancel_button.configure(state="disabled")
                    self.message.set(prep.error or "Setup cancelled. Your original files are unchanged.")
                    self.progress["value"] = 0
                    self.detail.set("File check stopped. Your original files are unchanged.")
                else:
                    try:
                        needed = prep.result["expanded_bytes"]
                        if shutil.disk_usage(Path(self.pending_import).parent).free < needed + 256 * 1024**2:
                            raise ValueError("Not enough free space for setup. The expanded iOS system needs up to %.1f GiB. Choose another storage location in Advanced." % (needed / 1024**3))
                        command = self.host.import_command(self.args, self.selected_source, self.pending_import, prep.result["sha256"])
                        self.progress["value"] = 0
                        self.launch(command, "import")
                    except (ValueError, OSError, RuntimeError) as error:
                        self.set_busy(False)
                        self.cancel_button.configure(state="disabled")
                        self.error(error)
        lines = self.session.poll()
        if self.session.active and self.job == "import":
            for line in lines:
                stage = re.fullmatch(r"import phase=(hashing|extracting|verifying|protecting) percent=(\d+) done=(\d+) total=(\d+)", line)
                if stage:
                    phase, percent, done, total = stage.groups()
                    labels = {"hashing": "Checking system archive", "extracting": "Preparing iOS system", "verifying": "Checking prepared system", "protecting": "Finalizing read-only system"}
                    self.progress["value"] = min(100, int(percent))
                    self.message.set("%s: %s%%" % (labels[phase], percent))
                    self.import_bytes = (int(done), int(total))
                    continue
                match = re.fullmatch(r"import (\d+)%", line)
                if match:
                    percent = min(100, int(match[1]))
                    self.progress["value"] = percent
                    self.message.set("Unpacking iOS system: %d%%" % percent if percent < 100 else "Checking the unpacked system…")
            elapsed = int(time.monotonic() - self.setup_started)
            detail = "%dm %02ds elapsed" % divmod(elapsed, 60)
            if getattr(self, "import_bytes", None):
                done, total = self.import_bytes
                detail += " · %.2f / %.2f GiB in this step" % (done / 1024**3, total / 1024**3)
            self.detail.set(detail + " · Original files stay unchanged.")
            if self.cancel_requested:
                self.message.set("Cancelling setup and removing the incomplete import…")
        if lines:
            self.log.configure(state="normal")
            self.log.delete("1.0", "end")
            self.log.insert("end", "\n".join(self.session.tail))
            self.log.see("end")
            self.log.configure(state="disabled")
        if self.session.active and self.job == "guest":
            state = self.session.status.get("state")
            for line in lines:
                if line.startswith("admission "):
                    self.message.set("Checking installed iOS system…")
            self.apps_button.configure(state="normal" if state == "2" and self.bridge and not self.session.stopping else "disabled")
            if not self.session.stopping and state:
                self.message.set({"1": "Starting iOS…", "2": "Guest running", "3": "Guest paused", "4": "Stopping guest…", "5": "Guest failed — retaining state"}.get(state, "Guest session"))
            if time.monotonic() - self.last_metrics >= 1:
                self.last_metrics = time.monotonic()
                self.update_metrics()
        if self.was_active and not self.session.active:
            # The process/reader may finish just after the earlier poll. Reap it
            # and drain its terminal receipt before interpreting the result.
            self.session.poll()
            self.finished()
            if self.closing and not (self.apps and self.apps.busy):
                self.window.destroy()
                return
        if self.closing and not self.preparation and not self.session.active and not (self.apps and self.apps.busy):
            self.window.destroy()
            return
        self.window.after(200, self.tick)

    def update_metrics(self):
        metrics = self.session.metrics()
        host, worker = metrics["host"], metrics["worker"]
        text = metrics.get("worker_status", "Worker CPU/RAM: waiting for native worker identity")
        if worker:
            cpu = "measuring" if worker["cpu_percent"] is None else "%.0f%%" % worker["cpu_percent"]
            memory = "unavailable" if worker["pss_bytes"] is None else "%.0f MiB PSS" % (worker["pss_bytes"] / 1024**2)
            text = "Emulator worker: %s CPU · %.1fs CPU · %s" % (cpu, worker["cpu_seconds"], memory)
        if "MemTotal" in host and "MemAvailable" in host:
            text += "\nHost RAM: %.0f / %.0f MiB used · CPU 100%% = one core" % ((host["MemTotal"] - host["MemAvailable"]) / 1024**2, host["MemTotal"] / 1024**2)
        if host.get("cpu_percent") is not None:
            text += "\nHost CPU: %.0f%% of all cores" % host["cpu_percent"]
        self.stats.set(text + "\nGuest OS CPU/RAM: unavailable")

    def finished(self):
        self.was_active = False
        job, self.job = self.job, ""
        if self.apps and self.apps.service:
            self.apps.service.cancel(guest_ended=True)
        if self.bridge:
            self.bridge.close()
            self.bridge = None
        self.set_busy(False)
        self.cancel_button.configure(state="disabled")
        self.apps_button.configure(state="disabled")
        self.stop_button.configure(state="disabled")
        if job == "import":
            if self.session.returncode == 0:
                self.vars["base"].set(self.pending_import)
                self.selected_source = None
                self.system_file.set(self.pending_import)
                self.progress["value"] = 100
                self.start_button.configure(text="Start iOS")
                self.message.set("Setup complete. Click Start iOS.")
                self.detail.set("This system is installed. Future sessions reuse it without importing again.")
                try:
                    self.store.save(self.profile())
                    self._list()
                except (ValueError, OSError, RuntimeError) as error:
                    self.error(error)
                self.pending_import = None
                self.import_bytes = None
            else:
                self.progress["value"] = 0
                self.message.set("Setup cancelled. Your original files are unchanged." if self.cancel_requested else "Setup failed. See Session details for the error; your original files are unchanged.")
        else:
            clean = self.host.clean_exit(self.session.returncode, self.session.final)
            self.message.set("Guest stopped cleanly. Ready for a fresh session." if clean else "Shutdown unconfirmed. State was retained; inspect the log before recovery.")
